class ModelParamsError(Exception):
    pass