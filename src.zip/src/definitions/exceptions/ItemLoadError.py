class ItemLoadError(Exception):
    pass