class SltStructureError(Exception):
    pass