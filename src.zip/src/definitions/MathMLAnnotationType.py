from enum import IntEnum


class MathMLAnnotationType(IntEnum):
    PRESENTATION = 0
    CONTENT = 1
